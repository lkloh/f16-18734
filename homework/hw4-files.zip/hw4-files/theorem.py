import re, sys
import math, random
import numpy as np

#### BEGIN----- functions to read movie files and create db ----- ####

def add_ratings(db, chunks, num):
    if(not db.has_key(chunks[0])):
        db[chunks[0]] = {}
    db[chunks[0]][num] = int(chunks[2])

def read_files(db, num):
    movie_file = "movies/"+num
    ratings = []
    fo = open(movie_file, "r")
    r = 0
    for line in fo:
        chunks = re.split(",", line)
        chunks[len(chunks)-1] = chunks[len(chunks)-1].strip()
        add_ratings(db, chunks, num)
        
#### END----- functions to read movie files and create db ----- ####

    
def score(w, aux, r):       
    '''
    Inputs: weights of movies, auxiliary information, and a record
    Returns the corresponding score
    '''
    #### ----- your code here ----- ####
    
    pass
    
    
def compute_weights(db):
    '''
    Input: database of users
    Returns weights of all movies
    '''
    #### ----- your code here ----- ####
    
    pass

#### BEGIN----- functions to create auxiliary records ----- ####
   
def create_aux(r, m, gamma):
    '''
    Inputs: a record r, and parameters m and gamma
    Returns auxiliary record for r with m attributes(movies)
    '''
    aux = {}
    if (m > len(r)):
        raw_input("m is greater than movies the user has seen. \nPress Enter to exit.")
        sys.exit(1)
    l = np.arange(len(r))
    random.shuffle(l)
    s = l[:m]
    i = 0
    for mv in r.keys():
        if(i in s):
            aux[mv] = add_noise(r[mv], gamma)
        i += 1
    return aux

def add_noise(val, gamma):
    '''
    Inputs: a value(rating) for an attribute(movie), and parameter gamma
    Returns the perturbed value, with the noise bounded by gamma
    '''
    min = val - 5*gamma
    max = val + 5*gamma
    if(max>5):
        max = 5
    if(min<0):
        min = 0
    perturbed_val = min + random.random()*(max-min)
    return perturbed_val
    
#### END----- functions to create auxiliary records ----- ####


#### BEGIN----- additional functions ----- ####


#### END----- additional functions ----- ####



if __name__ == "__main__":
    db = {}
    nums = ["03124", "06315", "07242", "16944", "17113", 
            "10935", "11977", "03276", "14199", "08191", 
            "06004", "01292", "15267", "03768", "02137"]
    for num in nums:
        read_files(db, num)  
    random.seed(9381)    # Do not change the seed
        
    #### ----- your code here ----- ####     

    
    
