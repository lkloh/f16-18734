CREATE TABLE attr_in_db (subattr VARCHAR2(50), supattr VARCHAR2(50) NOT NULL,time VARCHAR2(50) NOT NULL);
CREATE TABLE hasattrof_db (info VARCHAR2(50),  principal VARCHAR2(50) NOT NULL, attribute VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE send (sender VARCHAR2(50) NOT NULL,  receiver VARCHAR2(50) NOT NULL, message VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE inrelation (patient VARCHAR2(50) NOT NULL, principal VARCHAR2(50) NOT NULL, relation VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE refers (source VARCHAR2(50) NOT NULL, recipient VARCHAR2(50) NOT NULL, patient VARCHAR2(50) NOT NULL, reason VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);

CREATE TABLE prescribes (provider VARCHAR2(50) NOT NULL, patient VARCHAR2(50) NOT NULL, reason VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE  purp_in_db (subpurpose VARCHAR2(50) NOT NULL, suppurpose VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE is_participant_of_organized_health (principal VARCHAR2(50) NOT NULL, organizedhealth  VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE inrole_db (principal VARCHAR2(50) NOT NULL, role VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE beginrole (principal VARCHAR2(50) NOT NULL, role VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);
CREATE TABLE endrole (principal VARCHAR2(50) NOT NULL,  role VARCHAR2(50) NOT NULL, time VARCHAR2(50) NOT NULL);

INSERT INTO beginrole VALUES ('(str2prin "_hospital0")', 'covered-entity', '1971:04:01:18:00:00');
--INSERT INTO inrelation VALUES ('(str2prin "_p1")','(str2prin "_rv1")','treatment-relation', '1971:04:02:20:30:00');
--create patient
INSERT INTO hasattrof_db VALUES ('(str2info "_i1")','(str2prin "_p1")','(str2attr "_t1")','1971:04:01:19:00:00'); 
INSERT INTO attr_in_db VALUES ('(str2attr "_t1")','phi', '1971:04:01:19:00:00');
--INSERT INTO inrelation VALUES ('(str2prin "_p1")','(str2prin "_hospital0")','(str2rel "_r1")', '1971:04:01:19:00:00');
--yyyy:mm:dd:hh:min:sec

--hospital visit
-- new info and attr
INSERT INTO hasattrof_db VALUES ('(str2info "_i2")','(str2prin "_p1")','(str2attr "_t2")','1971:04:01:20:00:00'); 
INSERT INTO attr_in_db VALUES ('(str2attr "_t2")','phi', '1971:04:01:20:00:00');
INSERT INTO attr_in_db VALUES ('(str2attr "_t2")','psychotherapy-notes', '1971:04:01:20:00:00');

--disclose supposed auth
--INSERT INTO send VALUES ('(str2prin "_p1")','(str2prin "_hospital0")','(str2msg "_fake")', '1971:04:01:20:15:00');
-- disclosing info i1 (to rv1) which does not have psychotherapy notes
INSERT INTO send VALUES ('(str2prin "_hospital0")','(str2prin "_rv1")','(msg (str2info "_i2") (str2purp "_pp1"))', '1971:04:01:20:30:00');
--INSERT INTO send VALUES ('(str2prin "_hospital0")','(str2prin "_rv1")','(msg (str2info "_i1") (str2purp "_pp1"))','1971:04:01:20:30:00');

INSERT INTO inrole_db VALUES ('(str2prin "_rv1")','covered-entity', '1971:04:01:20:30:00');
INSERT INTO inrole_db VALUES ('(str2prin "_hospital0")','covered-entity', '1971:04:01:20:30:00');
INSERT INTO inrole_db VALUES ('(str2prin "_rv2")','covered-entity', '1971:04:01:20:30:00');

INSERT INTO is_participant_of_organized_health VALUES('(str2prin "_hospital0")', '(str2prin "_p3")', '1971:04:01:20:30:00');
INSERT INTO is_participant_of_organized_health VALUES('(str2prin "_rv1")', '(str2prin "_p3")', '1971:04:01:20:30:00');
INSERT INTO purp_in_db VALUES('(str2purp "_pp1")', '(healthcare-op (str2prin "_p3"))', '1971:04:01:20:30:00');

--prescription
INSERT INTO prescribes VALUES ('(str2prin "_rv1")','(str2prin "_p1")','prescription', '1971:04:01:20:45:00');
